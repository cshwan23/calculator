import UIKit


// level 1
var money = 3400

var fivehundredWon = money / 500
var onehundredWon = money % 500 / 100

print("오백원 \(fivehundredWon)개, 백원 \(onehundredWon)개")

//level 2

var money1 = 19000
var drink = 3000

var changeMoney = money1 - drink
var tenThousandWon =  (money1 - drink) / 10000
var fiveThousandWon = ((money1 - drink) % 10000) / 5000
var oneThousandWon = ((money1 - drink) % 5000) / 1000

print("거스름돈은 총 \(changeMoney) 원이구요, 만원짜리 \(tenThousandWon)개, 오천원짜리 \(fiveThousandWon)개, 천원짜리 \(oneThousandWon)개입니다")

//함수?

 

